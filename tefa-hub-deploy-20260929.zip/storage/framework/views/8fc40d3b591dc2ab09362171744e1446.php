<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['active' => 'dashboard']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['active' => 'dashboard']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<aside class="sidebar" aria-label="Navigasi Utama Siswa">
    <!-- Brand Logo & Title Header -->
    <div class="sidebar-header-top">
        <a href="<?php echo e(route('home')); ?>" class="sidebar-brand">
            <img src="<?php echo e(asset('assets/logo.png')); ?>" alt="Tefa-Hub Logo" class="sidebar-logo" onerror="this.onerror=null; this.src='<?php echo e(asset('assets/1.png')); ?>';">
            <div class="brand-text-group">
                <span class="brand-title">Tefa-Hub</span>
                <span class="brand-subtitle">DIGITAL VOKASI</span>
            </div>
        </a>
        <button type="button" class="sidebar-close-btn" id="sidebarCloseBtn" aria-label="Tutup Sidebar" title="Tutup Menu">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <line x1="18" y1="6" x2="6" y2="18"></line>
                <line x1="6" y1="6" x2="18" y2="18"></line>
            </svg>
        </button>
    </div>

    <!-- Section Title -->
    <div class="nav-section-title">MENU NAVIGASI</div>

    <!-- Navigation Links List -->
    <nav>
        <ul class="sidebar-nav-list">
            <li>
                <a href="<?php echo e(route('siswa.dashboard')); ?>" class="nav-item-link <?php echo e($active === 'dashboard' ? 'active' : ''); ?>">
                    Dashboard
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('siswa.akademik')); ?>" class="nav-item-link <?php echo e($active === 'akademik' ? 'active' : ''); ?>">
                    Akademik
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('siswa.blud')); ?>" class="nav-item-link <?php echo e($active === 'blud' ? 'active' : ''); ?>">
                    BLUD
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('siswa.bkk')); ?>" class="nav-item-link <?php echo e($active === 'bkk' ? 'active' : ''); ?>">
                    BKK Career Center
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('siswa.riwayat')); ?>" class="nav-item-link <?php echo e($active === 'riwayat' ? 'active' : ''); ?>">
                    Riwayat Aktivitas
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('siswa.tanya-tefa')); ?>" class="nav-item-link <?php echo e($active === 'tanya-tefa' ? 'active' : ''); ?>">
                    Tanya Tefa
                </a>
            </li>
        </ul>
    </nav>

    <!-- User Profile Footer -->
    <div class="sidebar-footer-profile">
        <div class="profile-avatar"><?php echo e(strtoupper(substr($user['name'] ?? 'Kirana Kinanti', 0, 2))); ?></div>
        <div class="profile-info">
            <span class="profile-name"><?php echo e($user['name'] ?? 'Kirana Kinanti'); ?></span>
            <span class="profile-role"><?php echo e($user['class'] ?? 'XII RPL 1'); ?></span>
        </div>
        <form method="POST" action="<?php echo e(route('logout')); ?>" class="sidebar-logout-form">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn-sidebar-logout" aria-label="Keluar / Logout" title="Keluar / Logout">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                    <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
                    <polyline points="16 17 21 12 16 7"></polyline>
                    <line x1="21" y1="12" x2="9" y2="12"></line>
                </svg>
            </button>
        </form>
    </div>
</aside>
<?php /**PATH C:\xampp\htdocs\tefa_hub\resources\views/components/sidebar-siswa.blade.php ENDPATH**/ ?>