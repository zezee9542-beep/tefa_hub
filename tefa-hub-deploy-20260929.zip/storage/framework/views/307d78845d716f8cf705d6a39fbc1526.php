<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Siswa — TEFA-Hub</title>

    <!-- Google Fonts: Plus Jakarta Sans -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <!-- Siswa Dashboard CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/siswa.dashboard.css')); ?>">
</head>
<body>

    <div class="app-layout">
        
        <!-- ═══════════════════════════════════════════
             SIDEBAR NAVIGASI SISWA
             ═══════════════════════════════════════════ -->
        <?php if (isset($component)) { $__componentOriginale1d69cdb243355bea6c7e739df7e7904 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale1d69cdb243355bea6c7e739df7e7904 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar-siswa','data' => ['active' => $activeMenu ?? 'dashboard','user' => $user ?? []]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar-siswa'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($activeMenu ?? 'dashboard'),'user' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($user ?? [])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale1d69cdb243355bea6c7e739df7e7904)): ?>
<?php $attributes = $__attributesOriginale1d69cdb243355bea6c7e739df7e7904; ?>
<?php unset($__attributesOriginale1d69cdb243355bea6c7e739df7e7904); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale1d69cdb243355bea6c7e739df7e7904)): ?>
<?php $component = $__componentOriginale1d69cdb243355bea6c7e739df7e7904; ?>
<?php unset($__componentOriginale1d69cdb243355bea6c7e739df7e7904); ?>
<?php endif; ?>

        <!-- ═══════════════════════════════════════════
             MAIN CONTENT AREA
             ═══════════════════════════════════════════ -->
        <main class="main-content">
            
            <!-- ═══════════════════════════════════════════
                 HEADER UTAMA ROLE SISWA (FULL TOP NO GAP)
                 ═══════════════════════════════════════════ -->
            <?php if (isset($component)) { $__componentOriginal916f30bd304886499075257a93e2674e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal916f30bd304886499075257a93e2674e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.header-siswa','data' => ['user' => $user ?? []]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('header-siswa'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['user' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($user ?? [])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal916f30bd304886499075257a93e2674e)): ?>
<?php $attributes = $__attributesOriginal916f30bd304886499075257a93e2674e; ?>
<?php unset($__attributesOriginal916f30bd304886499075257a93e2674e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal916f30bd304886499075257a93e2674e)): ?>
<?php $component = $__componentOriginal916f30bd304886499075257a93e2674e; ?>
<?php unset($__componentOriginal916f30bd304886499075257a93e2674e); ?>
<?php endif; ?>

            <!-- Page Body Area -->
            <div class="content-body">
                
                <!-- ═══════════════════════════════════════════
                     HERO PROFILE BANNER SISWA (928x256)
                     ═══════════════════════════════════════════ -->
                <?php if (isset($component)) { $__componentOriginaldbbdb6d2f76c9937608803aaf5a6c76c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldbbdb6d2f76c9937608803aaf5a6c76c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.profile-banner-siswa','data' => ['user' => $user ?? []]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('profile-banner-siswa'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['user' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($user ?? [])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldbbdb6d2f76c9937608803aaf5a6c76c)): ?>
<?php $attributes = $__attributesOriginaldbbdb6d2f76c9937608803aaf5a6c76c; ?>
<?php unset($__attributesOriginaldbbdb6d2f76c9937608803aaf5a6c76c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldbbdb6d2f76c9937608803aaf5a6c76c)): ?>
<?php $component = $__componentOriginaldbbdb6d2f76c9937608803aaf5a6c76c; ?>
<?php unset($__componentOriginaldbbdb6d2f76c9937608803aaf5a6c76c); ?>
<?php endif; ?>

                <!-- ═══════════════════════════════════════════
                     DOUBLE CHARTS GRID SISWA (2x 452x297)
                     ═══════════════════════════════════════════ -->
                <?php if (isset($component)) { $__componentOriginalb51cedfa67c7bf09a5c5f0cd12d5f01a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb51cedfa67c7bf09a5c5f0cd12d5f01a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard-charts-siswa','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard-charts-siswa'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb51cedfa67c7bf09a5c5f0cd12d5f01a)): ?>
<?php $attributes = $__attributesOriginalb51cedfa67c7bf09a5c5f0cd12d5f01a; ?>
<?php unset($__attributesOriginalb51cedfa67c7bf09a5c5f0cd12d5f01a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb51cedfa67c7bf09a5c5f0cd12d5f01a)): ?>
<?php $component = $__componentOriginalb51cedfa67c7bf09a5c5f0cd12d5f01a; ?>
<?php unset($__componentOriginalb51cedfa67c7bf09a5c5f0cd12d5f01a); ?>
<?php endif; ?>

                <!-- ═══════════════════════════════════════════
                     JADWAL PELAJARAN & PRAKTIK KEJURUAN
                     ═══════════════════════════════════════════ -->
                <?php if (isset($component)) { $__componentOriginaleebe58bdcd0045dd2b1fda9043f40c45 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaleebe58bdcd0045dd2b1fda9043f40c45 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.jadwal-pelajaran-siswa','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('jadwal-pelajaran-siswa'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaleebe58bdcd0045dd2b1fda9043f40c45)): ?>
<?php $attributes = $__attributesOriginaleebe58bdcd0045dd2b1fda9043f40c45; ?>
<?php unset($__attributesOriginaleebe58bdcd0045dd2b1fda9043f40c45); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaleebe58bdcd0045dd2b1fda9043f40c45)): ?>
<?php $component = $__componentOriginaleebe58bdcd0045dd2b1fda9043f40c45; ?>
<?php unset($__componentOriginaleebe58bdcd0045dd2b1fda9043f40c45); ?>
<?php endif; ?>

                <!-- ═══════════════════════════════════════════
                     RIWAYAT & LOG AKTIVITAS OTOMATIS (928x254)
                     ═══════════════════════════════════════════ -->
                <?php if (isset($component)) { $__componentOriginal6d2ec5783aab25ab289000f9283dcabc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6d2ec5783aab25ab289000f9283dcabc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.riwayat-aktivitas-siswa','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('riwayat-aktivitas-siswa'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6d2ec5783aab25ab289000f9283dcabc)): ?>
<?php $attributes = $__attributesOriginal6d2ec5783aab25ab289000f9283dcabc; ?>
<?php unset($__attributesOriginal6d2ec5783aab25ab289000f9283dcabc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6d2ec5783aab25ab289000f9283dcabc)): ?>
<?php $component = $__componentOriginal6d2ec5783aab25ab289000f9283dcabc; ?>
<?php unset($__componentOriginal6d2ec5783aab25ab289000f9283dcabc); ?>
<?php endif; ?>

            </div>

        </main>

        <!-- Sidebar Overlay Backdrop for Responsive Mobile/Tablet -->
        <div class="sidebar-backdrop" id="sidebarBackdrop"></div>

    </div>

    <!-- Responsive Sidebar Toggle Script -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const sidebar = document.querySelector('.sidebar');
            const mainContent = document.querySelector('.main-content');
            const toggleBtn = document.getElementById('sidebarToggleBtn');
            const closeBtn = document.getElementById('sidebarCloseBtn');
            const backdrop = document.getElementById('sidebarBackdrop');

            function toggleSidebar() {
                if (window.innerWidth <= 1024) {
                    sidebar.classList.toggle('sidebar-mobile-open');
                    backdrop.classList.toggle('active');
                    document.body.classList.toggle('sidebar-no-scroll');
                } else {
                    sidebar.classList.toggle('sidebar-desktop-collapsed');
                    mainContent.classList.toggle('content-expanded');
                }
            }

            function closeSidebar() {
                sidebar.classList.remove('sidebar-mobile-open');
                backdrop.classList.remove('active');
                document.body.classList.remove('sidebar-no-scroll');
            }

            if (toggleBtn) {
                toggleBtn.addEventListener('click', toggleSidebar);
            }

            if (closeBtn) {
                closeBtn.addEventListener('click', closeSidebar);
            }

            if (backdrop) {
                backdrop.addEventListener('click', closeSidebar);
            }
        });
    </script>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\tefa_hub\resources\views/siswa/dashboard.blade.php ENDPATH**/ ?>