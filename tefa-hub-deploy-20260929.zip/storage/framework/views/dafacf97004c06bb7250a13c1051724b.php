<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BKK Career Center — TEFA-Hub</title>

    <!-- Google Fonts: Plus Jakarta Sans -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <!-- Siswa Dashboard & Shared CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/siswa.dashboard.css')); ?>">
</head>
<body>

    <div class="app-layout">
        
        <!-- ═══════════════════════════════════════════
             SIDEBAR NAVIGASI SISWA
             ═══════════════════════════════════════════ -->
        <?php if (isset($component)) { $__componentOriginale1d69cdb243355bea6c7e739df7e7904 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale1d69cdb243355bea6c7e739df7e7904 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar-siswa','data' => ['active' => 'bkk','user' => $user ?? []]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar-siswa'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('bkk'),'user' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($user ?? [])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale1d69cdb243355bea6c7e739df7e7904)): ?>
<?php $attributes = $__attributesOriginale1d69cdb243355bea6c7e739df7e7904; ?>
<?php unset($__attributesOriginale1d69cdb243355bea6c7e739df7e7904); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale1d69cdb243355bea6c7e739df7e7904)): ?>
<?php $component = $__componentOriginale1d69cdb243355bea6c7e739df7e7904; ?>
<?php unset($__componentOriginale1d69cdb243355bea6c7e739df7e7904); ?>
<?php endif; ?>

        <!-- ═══════════════════════════════════════════
             MAIN CONTENT AREA
             ═══════════════════════════════════════════ -->
        <main class="main-content">
            
            <!-- ═══════════════════════════════════════════
                 HEADER UTAMA ROLE SISWA
                 ═══════════════════════════════════════════ -->
            <?php if (isset($component)) { $__componentOriginal916f30bd304886499075257a93e2674e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal916f30bd304886499075257a93e2674e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.header-siswa','data' => ['user' => $user ?? []]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('header-siswa'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['user' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($user ?? [])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal916f30bd304886499075257a93e2674e)): ?>
<?php $attributes = $__attributesOriginal916f30bd304886499075257a93e2674e; ?>
<?php unset($__attributesOriginal916f30bd304886499075257a93e2674e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal916f30bd304886499075257a93e2674e)): ?>
<?php $component = $__componentOriginal916f30bd304886499075257a93e2674e; ?>
<?php unset($__componentOriginal916f30bd304886499075257a93e2674e); ?>
<?php endif; ?>

            <!-- Page Body Area -->
            <div class="content-body">
                
                <!-- ═══════════════════════════════════════════
                     HERO CARD HEADER BKK (BURSA KERJA KHUSUS)
                     ═══════════════════════════════════════════ -->
                <div class="bkk-hero-banner" style="background-image: url('<?php echo e(asset('assets/Container (16).png')); ?>');" role="region" aria-label="Header Bursa Kerja Khusus BKK">
                    <div class="bkk-hero-content">
                        <div class="bkk-hero-badge">
                            <svg class="bkk-badge-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                                <rect width="20" height="14" x="2" y="7" rx="2" ry="2"/>
                                <path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/>
                            </svg>
                            <span>BURSA KERJA KHUSUS &amp; KARIR ALUMNI</span>
                        </div>
                        <h1 class="bkk-hero-title">Bursa Kerja Khusus &amp; Penyaluran Karir</h1>
                        <p class="bkk-hero-desc">Eksplorasi lowongan kerja &amp; magang industri terverifikasi, pantau kesiapan kompetensi vokasi, dan hubungkan portofolio siswa langsung ke mitra DUDI.</p>
                    </div>
                    <div class="bkk-hero-actions">
                        <a href="#rekomendasiLowongan" class="btn-bkk-explore" aria-label="Jelajahi Lowongan">
                            <svg class="btn-bkk-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                                <circle cx="11" cy="11" r="8"></circle>
                                <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                            </svg>
                            <span>Jelajahi Lowongan</span>
                        </a>
                    </div>
                </div>

                <!-- ═══════════════════════════════════════════
                     CARD KESIAPAN KERJA BKK (928px CARD)
                     ═══════════════════════════════════════════ -->
                <section class="bkk-card-wrapper">
                    
                    <!-- Header Baris Atas -->
                    <div class="bkk-card-header">
                        <div class="bkk-header-text">
                            <h2 class="bkk-title">Kesiapan Kerja BKK</h2>
                            <p class="bkk-subtitle">Evaluasi Skema Standar Industri</p>
                        </div>
                        <span class="bkk-badge-status">Siap Kerja</span>
                    </div>

                    <!-- Grid / Content Body -->
                    <div class="bkk-card-body">
                        
                        <!-- Side Kiri: Circle Progress Chart (Match Score) -->
                        <div class="bkk-chart-circle-wrap">
                            <svg class="bkk-circle-svg" viewBox="0 0 120 120">
                                <!-- Background Circle Track -->
                                <circle class="circle-bg" cx="60" cy="60" r="50" stroke="#EEF2FF" stroke-width="10" fill="none" />
                                <!-- Progress Circle Fill (84%) -->
                                <circle class="circle-fill" cx="60" cy="60" r="50" stroke="#004AC6" stroke-width="10" stroke-linecap="round" fill="none" 
                                        stroke-dasharray="314.16" stroke-dashoffset="50.26" transform="rotate(-90 60 60)" />
                            </svg>
                            <div class="bkk-circle-text">
                                <span class="circle-score">84%</span>
                                <span class="circle-label">Match Score</span>
                            </div>
                        </div>

                        <!-- Side Kanan: 3 Baris Progress Skills -->
                        <div class="bkk-skills-list">

                            <!-- Skill 1: Hard Skills (Coding & UI) -->
                            <div class="bkk-skill-item">
                                <div class="skill-info-row">
                                    <span class="skill-name">Hard Skills (Coding & UI)</span>
                                    <span class="skill-val val-blue">88%</span>
                                </div>
                                <div class="skill-bar-track">
                                    <div class="skill-bar-fill fill-blue" style="width: 88%;"></div>
                                </div>
                            </div>

                            <!-- Skill 2: Soft Skills (Kerja Tim) -->
                            <div class="bkk-skill-item">
                                <div class="skill-info-row">
                                    <span class="skill-name">Soft Skills (Kerja Tim)</span>
                                    <span class="skill-val val-purple">92%</span>
                                </div>
                                <div class="skill-bar-track">
                                    <div class="skill-bar-fill fill-purple" style="width: 92%;"></div>
                                </div>
                            </div>

                            <!-- Skill 3: Disiplin & K3 Industri -->
                            <div class="bkk-skill-item">
                                <div class="skill-info-row">
                                    <span class="skill-name">Disiplin & K3 Industri</span>
                                    <span class="skill-val val-green">95%</span>
                                </div>
                                <div class="skill-bar-track">
                                    <div class="skill-bar-fill fill-green" style="width: 95%;"></div>
                                </div>
                            </div>

                        </div>

                    </div>

                    <!-- Footer Note -->
                    <footer class="bkk-card-footer">
                        <span>Data tervalidasi oleh Guru Pembimbing & Mentor DUDI</span>
                    </footer>

                </section>

                <!-- ═══════════════════════════════════════════
                     SECTION REKOMENDASI LOWONGAN KERJA BKK (3 CARDS: 293x298)
                     ═══════════════════════════════════════════ -->
                <section class="bkk-jobs-section" id="rekomendasiLowongan" role="region" aria-label="Rekomendasi Lowongan Kerja">
                    
                    <!-- Section Header dengan Icon Container (26).png tanpa pembungkus pill -->
                    <div class="bkk-jobs-header">
                        <div class="bkk-jobs-badge-plain">
                            <img src="<?php echo e(asset('assets/Container (26).png')); ?>" alt="Peluang Baru" class="bkk-badge-plain-img">
                            <span class="bkk-badge-plain-text">PELUANG BARU MINGGU INI</span>
                        </div>
                        <h2 class="bkk-jobs-title">Rekomendasi Lowongan Sesuai Keahlian</h2>
                        <p class="bkk-jobs-subtitle">Kecocokan dihitung otomatis dari nilai TEFA RPL dan catatan portofolio Anda</p>
                    </div>

                    <!-- 3 Job Cards Grid (293x298) -->
                    <div class="bkk-jobs-grid">

                        <!-- ── CARD 1: PT Denso Manufacturing Indonesia ── -->
                        <div class="bkk-job-card">
                            <!-- Baris Atas: Badge Kecocokan & Deadline -->
                            <div class="job-card-top">
                                <span class="job-match-badge match-green">96% Kecocokan</span>
                                <span class="job-deadline-text">Ditutup 5 Hari</span>
                            </div>

                            <!-- Nama Perusahaan & Posisi -->
                            <div class="job-card-info">
                                <h3 class="job-company-name">PT Denso Manufacturing Indonesia</h3>
                                <span class="job-role-name">Industrial Software Apprentice</span>
                                <div class="job-location-row">
                                    <svg class="job-location-icon" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                                        <path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/>
                                        <circle cx="12" cy="10" r="3"/>
                                    </svg>
                                    <span>MM2100, Cikarang Barat</span>
                                </div>
                            </div>

                            <!-- Box Spesifikasi Gaji & Jurusan -->
                            <div class="job-details-box">
                                <div class="job-detail-row">
                                    <span class="detail-label">Uang Saku/Gaji:</span>
                                    <span class="detail-value">Rp 4.800.000 / bln</span>
                                </div>
                                <div class="job-detail-row">
                                    <span class="detail-label">Syarat Jurusan:</span>
                                    <span class="detail-value">RPL / Mekatronika</span>
                                </div>
                            </div>

                            <!-- Tombol Action (245x36, #004AC6) -->
                            <div class="job-card-action">
                                <button type="button" class="btn-job-apply" aria-label="Lamar di PT Denso Manufacturing Indonesia">
                                    <span>Lamar Sekarang</span>
                                </button>
                            </div>
                        </div>

                        <!-- ── CARD 2: PT United Tractors Tbk ── -->
                        <div class="bkk-job-card">
                            <!-- Baris Atas: Badge Kecocokan & Deadline -->
                            <div class="job-card-top">
                                <span class="job-match-badge match-blue">91% Kecocokan</span>
                                <span class="job-deadline-text">Ditutup 12 Hari</span>
                            </div>

                            <!-- Nama Perusahaan & Posisi -->
                            <div class="job-card-info">
                                <h3 class="job-company-name">PT United Tractors Tbk</h3>
                                <span class="job-role-name">Data Entry &amp; Operations Support Trainee</span>
                                <div class="job-location-row">
                                    <svg class="job-location-icon" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                                        <path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/>
                                        <circle cx="12" cy="10" r="3"/>
                                    </svg>
                                    <span>Cakung, Jakarta Timur</span>
                                </div>
                            </div>

                            <!-- Box Spesifikasi Gaji & Jurusan -->
                            <div class="job-details-box">
                                <div class="job-detail-row">
                                    <span class="detail-label">Uang Saku/Gaji:</span>
                                    <span class="detail-value">Rp 5.200.000 / bln</span>
                                </div>
                                <div class="job-detail-row">
                                    <span class="detail-label">Syarat Jurusan:</span>
                                    <span class="detail-value">RPL / TKJ / Logistik</span>
                                </div>
                            </div>

                            <!-- Tombol Action (245x36, #004AC6) -->
                            <div class="job-card-action">
                                <button type="button" class="btn-job-apply" aria-label="Lamar di PT United Tractors Tbk">
                                    <span>Lamar Sekarang</span>
                                </button>
                            </div>
                        </div>

                        <!-- ── CARD 3: Studio Animasi Infinite ── -->
                        <div class="bkk-job-card">
                            <!-- Baris Atas: Badge Kecocokan & Deadline -->
                            <div class="job-card-top">
                                <span class="job-match-badge match-purple">87% Kecocokan</span>
                                <span class="job-deadline-text">Ditutup 8 Hari</span>
                            </div>

                            <!-- Nama Perusahaan & Posisi -->
                            <div class="job-card-info">
                                <h3 class="job-company-name">Studio Animasi Infinite</h3>
                                <span class="job-role-name">Junior UI Artist &amp; Asset Modeler</span>
                                <div class="job-location-row">
                                    <svg class="job-location-icon" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                                        <path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/>
                                        <circle cx="12" cy="10" r="3"/>
                                    </svg>
                                    <span>Nongsa Digital Park, Batam</span>
                                </div>
                            </div>

                            <!-- Box Spesifikasi Gaji & Jurusan -->
                            <div class="job-details-box">
                                <div class="job-detail-row">
                                    <span class="detail-label">Uang Saku/Gaji:</span>
                                    <span class="detail-value">Rp 4.500.000 / bln</span>
                                </div>
                                <div class="job-detail-row">
                                    <span class="detail-label">Syarat Jurusan:</span>
                                    <span class="detail-value">RPL / Animasi / DKV</span>
                                </div>
                            </div>

                            <!-- Tombol Action (245x36, #004AC6) -->
                            <div class="job-card-action">
                                <button type="button" class="btn-job-apply" aria-label="Lamar di Studio Animasi Infinite">
                                    <span>Lamar Sekarang</span>
                                </button>
                            </div>
                        </div>

                    </div>

                </section>

            </div>

        </main>

        <!-- Sidebar Overlay Backdrop for Responsive Mobile/Tablet -->
        <div class="sidebar-backdrop" id="sidebarBackdrop"></div>

    </div>

    <!-- Responsive Sidebar Toggle Script -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const sidebar = document.querySelector('.sidebar');
            const mainContent = document.querySelector('.main-content');
            const toggleBtn = document.getElementById('sidebarToggleBtn');
            const closeBtn = document.getElementById('sidebarCloseBtn');
            const backdrop = document.getElementById('sidebarBackdrop');

            function toggleSidebar() {
                if (window.innerWidth <= 1024) {
                    sidebar.classList.toggle('sidebar-mobile-open');
                    backdrop.classList.toggle('active');
                    document.body.classList.toggle('sidebar-no-scroll');
                } else {
                    sidebar.classList.toggle('sidebar-desktop-collapsed');
                    mainContent.classList.toggle('content-expanded');
                }
            }

            function closeSidebar() {
                sidebar.classList.remove('sidebar-mobile-open');
                backdrop.classList.remove('active');
                document.body.classList.remove('sidebar-no-scroll');
            }

            if (toggleBtn) toggleBtn.addEventListener('click', toggleSidebar);
            if (closeBtn) closeBtn.addEventListener('click', closeSidebar);
            if (backdrop) backdrop.addEventListener('click', closeSidebar);
        });
    </script>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\tefa_hub\resources\views/siswa/bkk.blade.php ENDPATH**/ ?>