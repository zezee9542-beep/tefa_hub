<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Tefa-Hub — Satu ekosistem digital terpadu untuk akademik, BLUD teaching factory, dan career center siswa SMK.">
    <title>Tefa-Hub | Satu Ekosistem Digital untuk Seluruh Perjalanan Siswa</title>
    <link rel="icon" type="image/png" href="<?php echo e(asset('assets/logo.png')); ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/landing.css')); ?>">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>
<body>

    
    <div class="glow-tl" aria-hidden="true"></div>

    
    <header class="site-header">
        <div class="wrap">
            <a href="<?php echo e(url('/')); ?>" class="brand" aria-label="Tefa-Hub Beranda">
                <img src="<?php echo e(asset('assets/logo.png')); ?>" alt="Logo Tefa-Hub">
                <span class="brand-name">Tefa<span>-Hub</span></span>
            </a>

            <nav aria-label="Navigasi Utama">
                <ul class="nav-links">
                    <li><a href="#akademik">Akademik</a></li>
                    <li><a href="#blud">BLUD</a></li>
                    <li><a href="#career-center">Career Center (BKK)</a></li>
                </ul>
            </nav>

            <a href="<?php echo e(Route::has('login') ? route('login') : '#login'); ?>" class="btn-masuk">
                Masuk
            </a>
        </div>
    </header>

    
    <main class="hero">
        <div class="wrap">

            
            <section class="hero-content">
                <div class="pill-badge">
                    <span class="pill-dot" aria-hidden="true"></span>
                    <span class="pill-text">Ekosistem Pendidikan Vokasi Terpadu</span>
                </div>

                <h1 class="hero-title">
                    <span class="l1"><span class="hi">Satu</span> Ekosistem Digital</span>
                    <span class="l2">untuk Seluruh</span>
                    <span class="l3">Perjalanan Siswa</span>
                </h1>

                <p class="hero-desc">
                    Cari, kelola, dan pantau semua kegiatan sekolahmu di satu tempat —
                    mulai dari pembelajaran akademik, teaching factory BLUD, hingga peluang karir industri.
                </p>

                <div class="search-wrap">
                    <form action="#search" method="GET" class="search-box" role="search">
                        <span class="s-icon" aria-hidden="true">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
                                <circle cx="11" cy="11" r="7"/>
                                <line x1="16.5" y1="16.5" x2="22" y2="22" stroke-linecap="round"/>
                            </svg>
                        </span>
                        <input
                            type="text" name="q"
                            class="s-input"
                            placeholder="Cari informasi yang kamu butuhkan..."
                            aria-label="Cari informasi"
                            autocomplete="off"
                        >
                        <button type="submit" class="s-btn" aria-label="Cari">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
                                <line x1="5" y1="12" x2="19" y2="12" stroke-linecap="round"/>
                                <polyline points="12 5 19 12 12 19" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </button>
                    </form>
                </div>
            </section>

            
            <section class="hero-visual" aria-label="Visualisasi Siswa Tefa-Hub">

                
                <div class="aura-wrap" aria-hidden="true">
                    <div class="orb orb-b"></div>
                    <div class="orb orb-p"></div>
                    <div class="orb orb-v"></div>
                    <div class="orb orb-k"></div>
                </div>

                
                <div class="dots" aria-hidden="true">
                    <?php for($i = 0; $i < 42; $i++): ?>
                        <span class="dot"></span>
                    <?php endfor; ?>
                </div>

                
                <div class="students-wrap">
                    <img
                        src="<?php echo e(asset('assets/human.png')); ?>"
                        alt="Siswa dan Siswi SMK Tefa-Hub"
                        class="students-img"
                    >
                </div>

                
                <?php
                    $cards = [
                        ['icon' => 'card.png', 'title' => 'BKK Instan',  'desc' => 'Temukan informasi lowongan dan peluang kerja terbaru.',      'href' => '#bkk'],
                        ['icon' => 'book.png', 'title' => 'PPDB Kilat',  'desc' => 'Daftar sebagai calon peserta didik baru dengan mudah.',       'href' => '#ppdb'],
                    ];
                ?>

                <div class="cards-row">
                    <?php $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card" role="button" tabindex="0"
                             onclick="window.location.href='<?php echo e($card['href']); ?>'">
                            <div class="card-head">
                                <div class="card-icon">
                                    <img src="<?php echo e(asset('assets/' . $card['icon'])); ?>" alt="Icon <?php echo e($card['title']); ?>">
                                </div>
                                <h2 class="card-title"><?php echo e($card['title']); ?></h2>
                            </div>
                            <p class="card-desc"><?php echo e($card['desc']); ?></p>
                            <div class="card-foot">
                                <button class="btn-arrow" title="Buka <?php echo e($card['title']); ?>">
                                    <img src="<?php echo e(asset('assets/back.png')); ?>" alt="Lanjut">
                                </button>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

            </section>
        </div>
    </main>

    
    <section class="about-section" id="tentang">
        <div class="wrap">

            
            <div class="about-visual">
                <img src="<?php echo e(asset('assets/logo2.png')); ?>" alt="Logo Tefa-Hub" class="about-logo-img">
            </div>

            
            <div class="about-content">
                <span class="about-category">SOLUSI DIGITAL TERPADU</span>

                <h2 class="about-title">
                    Apa itu <span class="gradient-text">Tefa–Hub</span> ?
                </h2>

                <p class="about-desc">
                    Tefa-Hub adalah platform digital terintegrasi yang dirancang untuk mengelola
                    seluruh ekosistem pendidikan dan pengembangan kompetensi di sekolah
                    dalam satu sistem. Platform ini mengintegrasikan berbagai layanan strategis,
                    mulai dari kurikulum sekolah, unit bisnis Teaching Factory (BLUD), Praktik Kerja
                    Lapangan (PKL), hingga penelusuran lulusan dan rekrutmen kerja industri.
                </p>
            </div>

        </div>
    </section>

    
    <section class="services-section" id="layanan">
        <div class="wrap">

            <div class="services-header">
                <h2 class="services-title">Semua Kebutuhan Siswa, Satu Platform</h2>
                <p class="services-desc">
                    Akses berbagai layanan sekolah yang terintegrasi untuk mendukung perjalananmu dari
                    pembelajaran hingga persiapan dunia kerja.
                </p>
            </div>

            <?php
                $services = [
                    [
                        'icon' => '1.png',
                        'title' => 'Penerimaan Peserta Didik Baru',
                        'desc' => 'Dokumentasi lengkap kegiatan industri. Memudahkan pengisian Logbook Harian dan pemantauan real-time oleh sekolah dan mitra industri.',
                        'link' => '#ppdb',
                    ],
                    [
                        'icon' => '2.png',
                        'title' => 'Akademik Terintegrasi',
                        'desc' => 'Pusat pengelolaan pembelajaran digital mulai dari materi, tugas, hingga transparansi nilai dan Rapor Digital dalam satu akses.',
                        'link' => '#akademik',
                    ],
                    [
                        'icon' => '3.png',
                        'title' => 'Produk Unggulan (BLUD)',
                        'desc' => 'Wadah publikasi karya dan jasa hasil kreativitas siswa. Mendukung kewirausahaan dengan menampilkan produk langsung di landing page publik.',
                        'link' => '#blud',
                    ],
                    [
                        'icon' => '4.png',
                        'title' => 'Career Center (BKK)',
                        'desc' => 'Jembatan menuju dunia kerja. Membantu siswa dan alumni melamar pekerjaan menggunakan CV Digital & Portofolio ke jaringan mitra industri.',
                        'link' => '#career-center',
                    ],
                ];
            ?>

            <div class="services-grid">
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="service-card">
                        <div class="service-card-body">
                            <div class="service-icon">
                                <img src="<?php echo e(asset('assets/' . $service['icon'])); ?>" alt="<?php echo e($service['title']); ?>">
                            </div>
                            <h3 class="service-card-title"><?php echo e($service['title']); ?></h3>
                            <p class="service-card-desc"><?php echo e($service['desc']); ?></p>
                        </div>
                        <a href="<?php echo e($service['link']); ?>" class="service-btn">
                            Lihat Selengkapnya
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>
    </section>

    
    <section class="showcase-section" id="produk">
        <div class="wrap">

            
            <div class="showcase-content">
                <span class="showcase-category">TEACHING FACTORY KE PUBLIK</span>

                <h2 class="showcase-title">Dari Karya Menjadi Produk</h2>

                <p class="showcase-desc">
                    Tefa-Hub menghubungkan kegiatan Teaching Factory dengan layanan BLUD untuk
                    memperkenalkan, mengelola, dan mengembangkan produk unggulan hasil karya siswa
                    ke pasar luas secara profesional.
                </p>

                <a href="#produk" class="showcase-btn">
                    Lihat Selengkapnya
                </a>
            </div>

            
            <div class="showcase-visual">
                <div class="showcase-cards">
                    <img src="<?php echo e(asset('assets/card2.png')); ?>" alt="Card Jasa Layanan" class="showcase-card showcase-card-1">
                    <img src="<?php echo e(asset('assets/card1.png')); ?>" alt="Card Teaching Factory" class="showcase-card showcase-card-2">
                </div>
            </div>

        </div>
    </section>

    
    <section class="ai-section" id="tanya-tefa">
        <div class="wrap">

            
            <div class="ai-visual">
                <img src="<?php echo e(asset('assets/ai.png')); ?>" alt="Tefa AI Assistant" class="ai-img">
            </div>

            
            <div class="ai-content">
                <span class="ai-category">PUSAT BANTUAN CERDAS</span>

                <h2 class="ai-title">Butuh Informasi ? Tanya Tefa</h2>

                <p class="ai-desc">
                    Tanyakan berbagai informasi seputar akademik, PKL, BLUD, hingga Career
                    Center dan dapatkan jawaban dengan lebih mudah melalui Tefa, asisten
                    digital Tefa-Hub.
                </p>

                <?php
                    $aiFeatures = [
                        [
                            'icon' => '11.png',
                            'title' => 'Layanan Bantuan 24/7',
                            'desc' => 'Chatbot AI menyediakan pusat bantuan interaktif yang siap kapan saja.',
                        ],
                        [
                            'icon' => '12.png',
                            'title' => 'Respon Cepat (Fast)',
                            'desc' => 'Kecepatan dalam memberikan informasi secara instan dan tepat.',
                        ],
                        [
                            'icon' => '13.png',
                            'title' => 'Efisiensi Signifikan',
                            'desc' => 'Mengurangi hingga lebih dari 80% pertanyaan rutin berulang.',
                        ],
                    ];
                ?>

                <div class="ai-cards">
                    <?php $__currentLoopData = $aiFeatures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="ai-card">
                            <div class="ai-card-icon">
                                <img src="<?php echo e(asset('assets/' . $feat['icon'])); ?>" alt="<?php echo e($feat['title']); ?>">
                            </div>
                            <h3 class="ai-card-title"><?php echo e($feat['title']); ?></h3>
                            <p class="ai-card-desc"><?php echo e($feat['desc']); ?></p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

        </div>
    </section>

    
    <section class="cta-banner-section">
        <div class="wrap">
            <div class="cta-banner-card">
                <h2 class="cta-banner-title">
                    Wujudkan Potensi Kejuruan &amp;<br>
                    Siapkan Kariermu Bersama<br>
                    Tefa–Hub
                </h2>

                <p class="cta-banner-desc">
                    Dari sinkronisasi kurikulum, validasi produk BLUD, hingga rekrutmen industri<br>
                    otomatis dalam satu ekosistem terpadu.
                </p>

                <a href="<?php echo e(Route::has('login') ? route('login') : '#login'); ?>" class="cta-banner-btn">
                    Mulai Sekarang
                </a>
            </div>
        </div>
    </section>

    
    <footer class="site-footer">
        <div class="wrap">

            
            <div class="footer-grid">

                
                <div class="footer-col footer-col-brand">
                    <a href="<?php echo e(url('/')); ?>" class="brand" aria-label="Tefa-Hub Beranda">
                        <img src="<?php echo e(asset('assets/logo.png')); ?>" alt="Logo Tefa-Hub">
                        <span class="brand-name">Tefa<span>-Hub</span></span>
                    </a>

                    <p class="footer-bio">
                        Platform ekosistem digital terintegrasi untuk menghubungkan pendidikan vokasi,
                        Teaching Factory (BLUD), dan dunia industri secara efektif.
                    </p>

                    <div class="footer-socials">
                        <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn">
                            <svg viewBox="0 0 24 24" fill="currentColor">
                                <path d="M19 3a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14m-.5 15.5v-5.3a3.26 3.26 0 0 0-3.26-3.26c-.85 0-1.84.52-2.28 1.3v-1.11h-2.79v8.37h2.79v-4.93c0-.77.62-1.4 1.39-1.4a1.4 1.4 0 0 1 1.4 1.4v4.93h2.75M6.46 10.9v8.37H9.25V10.9H6.46M7.86 6.78a1.62 1.62 0 1 0 0 3.24 1.62 1.62 0 0 0 0-3.24z"/>
                            </svg>
                        </a>
                        <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" aria-label="Instagram">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <rect x="2" y="2" width="20" height="20" rx="5" ry="5"/>
                                <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/>
                                <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/>
                            </svg>
                        </a>
                    </div>
                </div>

                
                <div class="footer-col">
                    <h3 class="footer-col-title">NAVIGASI</h3>
                    <ul class="footer-links">
                        <li><a href="<?php echo e(url('/')); ?>">Beranda</a></li>
                        <li><a href="#akademik">Akademik</a></li>
                        <li><a href="#blud">BLUD</a></li>
                        <li><a href="#career-center">Career Center</a></li>
                    </ul>
                </div>

                
                <div class="footer-col">
                    <h3 class="footer-col-title">FITUR UNGGULAN</h3>
                    <ul class="footer-links">
                        <li><a href="#rapor">E-Rapor Vokasi</a></li>
                        <li><a href="#blud">Kurasi BLUD</a></li>
                        <li><a href="#bkk">Pelacak BKK</a></li>
                        <li><a href="#cv">CV &amp; Portofolio</a></li>
                        <li><a href="#tanya-tefa">Tanya Tefa AI</a></li>
                    </ul>
                </div>

                
                <div class="footer-col footer-col-newsletter">
                    <h3 class="footer-col-title">BULETIN VOKASI</h3>
                    <p class="newsletter-desc">
                        Dapatkan info lowongan kerja, sertifikasi kompetensi BNSP, dan inovasi karya terbaru.
                    </p>

                    <form action="#subscribe" method="POST" class="newsletter-box" onsubmit="event.preventDefault();">
                        <input type="email" placeholder="Alamat email..." class="newsletter-input" required>
                        <button type="submit" class="newsletter-btn">
                            Langganan
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                                <polyline points="9 18 15 12 9 6" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </button>
                    </form>
                </div>

            </div>

            
            <div class="footer-bottom">
                <div class="copyright">
                    &copy; 2026 Tefa-Hub Ecosystem. Hak Cipta Dilindungi.
                </div>
                <div class="legal-links">
                    <a href="#privasi">Kebijakan Privasi</a>
                    <a href="#syarat">Syarat &amp; Ketentuan</a>
                    <a href="#keamanan">Keamanan</a>
                    <a href="#cookie">Cookie</a>
                </div>
            </div>

        </div>
    </footer>

    

    
    <button id="ai-toggle-btn" class="ai-trigger" aria-label="Pusat Bantuan Tefa-Hub" title="Ada yang bisa kami bantu?">
        <img src="<?php echo e(asset('assets/Group 106 1 (1).png')); ?>" alt="Tanya Tefa AI" class="ai-trigger-img">
        <span class="ai-trigger-badge" id="ai-notif-badge" style="display:none;"></span>
    </button>

    
    <div id="ai-navigator-panel" class="ai-panel" role="dialog" aria-label="Pusat Bantuan Tefa-Hub" aria-hidden="true">

        
        <div class="ai-header">
            <div class="ai-header-brand">
                <div class="ai-header-dot"></div>
                <span class="ai-header-title">Pusat Bantuan</span>
            </div>
            <div class="ai-header-actions">
                <span class="ai-header-sub">Tefa-Hub · Selalu siap</span>
                <button class="ai-close-btn" id="ai-close-btn" aria-label="Tutup">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round">
                        <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
                    </svg>
                </button>
            </div>
        </div>

        
        <div class="ai-greeting-card" id="ai-greeting-card">
            <p class="ai-greeting-label">Halo! Saya Tanya Tefa AI 👋</p>
            <p class="ai-greeting-sub">Navigator sistem & pusat bantuan TEFA-Hub. Pilih peran Anda untuk panduan langsung:</p>
            <div class="ai-nav-categories">
                <button class="ai-nav-cat" onclick="sendNavChip('Saya Orang Tua / Calon Siswa (Info PPDB)')">
                    <span class="ai-nav-cat-icon">👨‍👩‍👧</span>
                    <div><strong>Orang Tua & Calon</strong><span>PPDB & Jurusan</span></div>
                </button>
                <button class="ai-nav-cat" onclick="sendNavChip('Saya Siswa Aktif SMK')">
                    <span class="ai-nav-cat-icon">🎓</span>
                    <div><strong>Siswa Aktif</strong><span>BLUD, PKL & Nilai</span></div>
                </button>
                <button class="ai-nav-cat" onclick="sendNavChip('Saya Alumni / Pencari Kerja')">
                    <span class="ai-nav-cat-icon">💼</span>
                    <div><strong>Alumni & Karir</strong><span>Loker & Legalisir</span></div>
                </button>
                <button class="ai-nav-cat" onclick="sendNavChip('Saya Mitra Industri / Perusahaan')">
                    <span class="ai-nav-cat-icon">🏢</span>
                    <div><strong>Mitra Industri</strong><span>Kerjasama TEFA</span></div>
                </button>
                <button class="ai-nav-cat" style="grid-column: span 2;" onclick="sendNavChip('Saya Butuh Layanan Tata Usaha (TU)')">
                    <span class="ai-nav-cat-icon">🏛️</span>
                    <div><strong>Layanan Tata Usaha & Bantuan Akun</strong><span>Jam operasional TU, surat & reset kata sandi</span></div>
                </button>
            </div>
        </div>

        
        <div class="ai-conversation" id="ai-messages" role="log" aria-live="polite">
            <div class="ai-loading-row" id="ai-initial-typing">
                <div class="ai-loading-dots"><span></span><span></span><span></span></div>
                <span class="ai-loading-text">Memuat...</span>
            </div>
        </div>

        
        <div class="ai-quick-actions" id="ai-suggestions"></div>

        
        <div class="ai-input-wrap">
            <form id="ai-chat-form" class="ai-form">
                <?php echo csrf_field(); ?>
                <input
                    type="text"
                    id="ai-message-input"
                    class="ai-field"
                    placeholder="Tulis pertanyaan Anda..."
                    autocomplete="off"
                    maxlength="500"
                    aria-label="Pertanyaan untuk tim Tefa-Hub"
                >
                <button type="submit" class="ai-submit" id="ai-send-btn" aria-label="Kirim pertanyaan">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                        <line x1="22" y1="2" x2="11" y2="13"/>
                        <polygon points="22 2 15 22 11 13 2 9 22 2" fill="currentColor" opacity="0.9" stroke="none"/>
                    </svg>
                </button>
            </form>
            <p class="ai-powered">Didukung teknologi AI · Tefa-Hub 2026</p>
        </div>
    </div>

    <script>
    (function () {
        'use strict';

        const GREET_URL  = '<?php echo e(route("ai.greet")); ?>';
        const CHAT_URL   = '<?php echo e(route("ai.chat")); ?>';
        const CSRF_TOKEN = document.querySelector('meta[name="csrf-token"]')?.content || '';

        const panel        = document.getElementById('ai-navigator-panel');
        const toggleBtn    = document.getElementById('ai-toggle-btn');
        const closeBtn     = document.getElementById('ai-close-btn');
        const conversation = document.getElementById('ai-messages');
        const form         = document.getElementById('ai-chat-form');
        const field        = document.getElementById('ai-message-input');
        const submitBtn    = document.getElementById('ai-send-btn');
        const quickActions = document.getElementById('ai-suggestions');
        const badge        = document.getElementById('ai-notif-badge');
        const greetCard    = document.getElementById('ai-greeting-card');
        const initLoading  = document.getElementById('ai-initial-typing');

        let isOpen    = false;
        let isBusy    = false;
        let greeted   = false;

        // ── Toggle ──────────────────────────────────────────────────────────
        function openPanel() {
            isOpen = true;
            panel.classList.add('is-open');
            panel.setAttribute('aria-hidden', 'false');
            badge.style.display = 'none';
            field.focus();
            if (!greeted) { greeted = true; loadGreeting(); }
        }

        function closePanel() {
            isOpen = false;
            panel.classList.remove('is-open');
            panel.setAttribute('aria-hidden', 'true');
        }

        toggleBtn.addEventListener('click', () => isOpen ? closePanel() : openPanel());
        closeBtn.addEventListener('click', closePanel);

        setTimeout(() => { if (!isOpen) { badge.style.display = 'flex'; } }, 3000);

        // ── Load greeting ───────────────────────────────────────────────────
        async function loadGreeting() {
            try {
                const r    = await fetch(GREET_URL);
                const data = await r.json();
                initLoading.remove();
                // Show default suggestions from greet response
                if (data.suggestions?.length) buildQuickActions(data.suggestions);
                else buildQuickActions(['Saya Orang Tua (Info PPDB)', 'Cara Daftar PPDB Online', 'Cara Publikasi Produk BLUD', 'Cara Melamar Lowongan BKK', 'Lupa Password Akun']);
            } catch {
                initLoading.remove();
                buildQuickActions(['Saya Orang Tua (Info PPDB)', 'Cara Daftar PPDB Online', 'Cara Publikasi Produk BLUD', 'Cara Melamar Lowongan BKK', 'Lupa Password Akun']);
            }
        }

        // ── Nav category shortcut ────────────────────────────────────────────
        function sendNavChip(text) {
            greetCard.style.display = 'none';
            quickActions.innerHTML  = '';
            field.value = text;
            form.dispatchEvent(new Event('submit', { bubbles: true }));
        }
        window.sendNavChip = sendNavChip;

        // ── Submit ──────────────────────────────────────────────────────────
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            const text = field.value.trim();
            if (!text || isBusy) return;

            // Hide greeting card on first message
            greetCard.style.display = 'none';
            quickActions.innerHTML  = '';

            appendQuestion(text);
            field.value = '';
            setBusy(true);

            try {
                const r    = await fetch(CHAT_URL, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': CSRF_TOKEN, 'Accept': 'application/json' },
                    body: JSON.stringify({ message: text }),
                });
                const data = await r.json();
                setBusy(false);
                appendReply(data);
            } catch {
                setBusy(false);
                appendReply({ answer: 'Koneksi terputus. Silakan coba kembali.' });
            }
        });

        // ── Quick action chips ──────────────────────────────────────────────
        function buildQuickActions(items) {
            quickActions.innerHTML = '';
            items.forEach(text => {
                const btn = document.createElement('button');
                btn.className   = 'ai-action-chip';
                btn.textContent = text;
                btn.addEventListener('click', () => { sendNavChip(text); });
                quickActions.appendChild(btn);
            });
        }

        // ── Message renderers ───────────────────────────────────────────────
        function appendQuestion(text) {
            const row = document.createElement('div');
            row.className   = 'ai-row ai-row--user';
            row.innerHTML   = `<div class="ai-msg ai-msg--user">${esc(text)}</div>`;
            conversation.appendChild(row);
            scrollEnd();
        }

        function appendReply(data) {
            const text  = (typeof data === 'string') ? data : (data.answer || 'Pertanyaan Anda sudah diterima.');
            const route = (typeof data === 'object') ? data.route : null;
            const label = (typeof data === 'object') ? data.label : null;
            const cat   = ((typeof data === 'object') ? (data.category || '') : '').toUpperCase();
            const sugg  = (typeof data === 'object' && Array.isArray(data.suggestions)) ? data.suggestions : [];

            // Category & Role badge
            let badgeCls = 'ai-badge-umum', badgeTxt = '🤖 Tanya Tefa AI Navigator';
            if (cat.includes('PPDB'))                            { badgeCls = 'ai-badge-ppdb';     badgeTxt = '👨‍👩‍👧 Info PPDB & Calon Siswa'; }
            else if (cat.includes('INDUSTRI'))                   { badgeCls = 'ai-badge-industri'; badgeTxt = '🏢 Kemitraan Industri (DUDI)'; }
            else if (cat.includes('BLUD'))                       { badgeCls = 'ai-badge-blud';     badgeTxt = '🏭 Unit Produksi BLUD'; }
            else if (cat.includes('BKK'))                        { badgeCls = 'ai-badge-bkk';      badgeTxt = '💼 Bursa Kerja (BKK)'; }
            else if (cat.includes('AKADEMIK'))                   { badgeCls = 'ai-badge-akademik'; badgeTxt = '🎓 Portal Akademik'; }
            else if (cat.includes('ADMIN')||cat.includes('FAQ')) { badgeCls = 'ai-badge-admin';    badgeTxt = '🏛️ Layanan Tata Usaha & Akun'; }

            // CTA button
            const ctaHtml = (route && label)
                ? `<a href="${route}" class="ai-cta-link ai-cta-link--nav">${esc(label)}<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg></a>`
                : '';

            // Followup chips
            const chipsHtml = sugg.length
                ? `<div class="ai-reply-chips">${sugg.map(s => `<button class="ai-reply-chip" onclick="sendNavChip('${esc(s)}')">${esc(s)}</button>`).join('')}</div>`
                : '';

            const row = document.createElement('div');
            row.className = 'ai-row ai-row--reply';
            row.innerHTML = `
                <div class="ai-msg ai-msg--reply">
                    <span class="ai-cat-badge ${badgeCls}">${badgeTxt}</span>
                    <div class="ai-reply-body">${mdFull(text)}</div>
                    ${ctaHtml}
                    ${chipsHtml}
                </div>`;
            conversation.appendChild(row);
            scrollEnd();

            // Refresh quick-action chips with new suggestions
            if (sugg.length) buildQuickActions(sugg);
        }

        // ── Busy state ──────────────────────────────────────────────────────
        function setBusy(state) {
            isBusy = state;
            submitBtn.disabled = state;
            field.disabled = state;

            if (state) {
                const row = document.createElement('div');
                row.id        = 'ai-busy-row';
                row.className = 'ai-row ai-row--reply';
                row.innerHTML = `<div class="ai-msg ai-msg--reply ai-msg--loading"><div class="ai-loading-dots"><span></span><span></span><span></span></div></div>`;
                conversation.appendChild(row);
                scrollEnd();
            } else {
                document.getElementById('ai-busy-row')?.remove();
            }
        }

        function scrollEnd() { conversation.scrollTop = conversation.scrollHeight; }

        function esc(s) {
            if (!s) return '';
            return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;');
        }

        function md(s) {
            return esc(s).replace(/\*\*(.*?)\*\*/g,'<strong>$1</strong>').replace(/\n/g,'<br>');
        }

        function mdFull(text) {
            if (!text) return '';
            let raw = esc(text);
            raw = raw.replace(/\*\*(.*?)\*\*/g,'<strong>$1</strong>');
            const lines = raw.split('\n');
            let out = '', inList = false, listType = 'ul';
            lines.forEach(line => {
                const t = line.trim();
                if (!t) { if (inList) { out += `</${listType}>`; inList = false; } return; }
                const nm = t.match(/^(\d+)\.\s+(.+)$/);
                if (nm) {
                    if (!inList || listType !== 'ol') { if (inList) out += `</${listType}>`; out += '<ol>'; inList = true; listType = 'ol'; }
                    out += `<li>${nm[2]}</li>`; return;
                }
                const bm = t.match(/^[•\-\*]\s+(.+)$/);
                if (bm) {
                    if (!inList || listType !== 'ul') { if (inList) out += `</${listType}>`; out += '<ul>'; inList = true; listType = 'ul'; }
                    out += `<li>${bm[1]}</li>`; return;
                }
                if (inList) { out += `</${listType}>`; inList = false; }
                out += `<p>${t}</p>`;
            });
            if (inList) out += `</${listType}>`;
            return out;
        }
    })();
    </script>

</body>
</html>`n<?php /**PATH C:\xampp\htdocs\tefa_hub\resources\views/welcome.blade.php ENDPATH**/ ?>