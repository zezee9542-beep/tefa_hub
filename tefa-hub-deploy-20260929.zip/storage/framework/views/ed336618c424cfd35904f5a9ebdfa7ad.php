<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['user' => []]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['user' => []]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div class="profile-hero-card" role="region" aria-label="Banner Profil Siswa">
    <!-- Ambient Layer Blur Background Eclipses -->
    <div class="card-eclipse-blur eclipse-blue-corner" aria-hidden="true"></div>
    <div class="card-eclipse-blur eclipse-purple-bottom" aria-hidden="true"></div>

    <!-- Sisi Kiri: Foto Profil & Tombol Edit -->
    <div class="profile-card-left">
        <div class="profile-avatar-wrapper">
            <img src="<?php echo e($user['avatar'] ?? asset('assets/orng.png')); ?>" alt="<?php echo e($user['name'] ?? 'Foto Profil Siswa'); ?>" class="profile-avatar-img">
        </div>
        <button type="button" class="btn-edit-profile" aria-label="Edit profil" onclick="openEditProfileModal()">
            Edit profil
        </button>
    </div>

    <!-- Sisi Kanan: Status, Sapaan & Progress Transisi Alumni -->
    <div class="profile-card-right">
        <!-- Baris 1: Status Siswa Aktif & NISN -->
        <div class="profile-meta-row">
            <div class="badge-siswa-tefa">
                <span class="tefa-dot" aria-hidden="true"></span>
                <span class="tefa-text">SISWA AKTIF TEFA</span>
            </div>
            
            <div class="profile-nisn-info">
                <img src="<?php echo e(asset('assets/lis.png')); ?>" alt="Verified NISN" class="icon-verified-lis" width="16" height="16">
                <span>NISN: <?php echo e($user['nisn'] ?? '0064829104'); ?> • <?php echo e($user['class'] ?? 'XII RPL 1'); ?></span>
            </div>
        </div>

        <!-- Baris 2: Sapaan Selamat Datang -->
        <div class="profile-welcome-group">
            <h2 class="welcome-heading">Selamat Datang kembali,</h2>
            <h2 class="welcome-name"><?php echo e($user['name'] ?? 'Kirana Kinanti'); ?>!</h2>
        </div>

        <!-- Baris 3: Status Role & Transisi Alumni (Progress Chart) -->
        <div class="role-transition-box">
            <div class="transition-header">
                <div class="transition-title-wrap">
                    <img src="<?php echo e(asset('assets/run.png')); ?>" alt="Role Status Icon" class="transition-icon" width="16" height="16">
                    <span class="transition-title">Status Role & Transisi Alumni</span>
                </div>
                <span class="badge-terintegrasi">Terintegrasi</span>
            </div>

            <!-- Progress Bar Indikator -->
            <div class="transition-progress-track" role="progressbar" aria-valuenow="82" aria-valuemin="0" aria-valuemax="100">
                <div class="transition-progress-fill" style="width: 82%;"></div>
            </div>

            <div class="transition-footer">
                <span class="transition-semester">Semester Akhir (Kelas XII)</span>
                <span class="transition-percentage">82% Fase Kelulusan</span>
            </div>
        </div>
    </div>
</div>

<!-- Modal Pop-Up Edit Profil Siswa -->
<?php if (isset($component)) { $__componentOriginal3b143fe5c10c782fe26e346cfa643096 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b143fe5c10c782fe26e346cfa643096 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal-edit-profil','data' => ['user' => $user ?? []]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal-edit-profil'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['user' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($user ?? [])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b143fe5c10c782fe26e346cfa643096)): ?>
<?php $attributes = $__attributesOriginal3b143fe5c10c782fe26e346cfa643096; ?>
<?php unset($__attributesOriginal3b143fe5c10c782fe26e346cfa643096); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b143fe5c10c782fe26e346cfa643096)): ?>
<?php $component = $__componentOriginal3b143fe5c10c782fe26e346cfa643096; ?>
<?php unset($__componentOriginal3b143fe5c10c782fe26e346cfa643096); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\tefa_hub\resources\views/components/profile-banner-siswa.blade.php ENDPATH**/ ?>